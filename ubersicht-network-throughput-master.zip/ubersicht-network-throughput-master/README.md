# Network Throughput

This widget is adapted from Adam Courtemanche's network-throughput. The primary differences are in the visual aspects of the widget. Specifically, rounded corners, a different font and color scheme, and less text are used.

![](screenshot.png)
