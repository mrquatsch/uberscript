A couple few widgets for [Übersicht](http://tracesof.net/uebersicht/).
